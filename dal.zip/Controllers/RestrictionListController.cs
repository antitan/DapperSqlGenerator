﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RestrictionListController : ControllerBase
    {
        private readonly ILogger<RestrictionListController> logger;
        private readonly IRestrictionListService restrictionListService;

        public RestrictionListController(IRestrictionListService restrictionListService, ILogger<RestrictionListController> logger)
        {
            this.restrictionListService = restrictionListService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new RestrictionList entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(RestrictionListRequestAddDto restrictionListRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = restrictionListRequestAddDto.ToEntity();
                await restrictionListService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in restrictionListController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update RestrictionList entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(RestrictionListRequestUpdateDto restrictionListRequestUpdateDto)
        {
            try
            {
                var restrictionList = await restrictionListService.GetByIdAsync(restrictionListRequestUpdateDto.Id);
                if (restrictionList == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await restrictionListService.UpdateAsync(restrictionList);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in restrictionListController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete RestrictionList entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var restrictionList = await restrictionListService.GetByIdAsync(id);
                if (restrictionList == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await restrictionListService.DeleteAsync(restrictionList);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in restrictionListController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get RestrictionList by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(RestrictionListResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            RestrictionListResponseGetByIdDto? restrictionListResponseGetByIdDto = null;
            try
            {
                var entity = await restrictionListService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                restrictionListResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in RestrictionListController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(restrictionListResponseGetByIdDto);
        }



    }

}
