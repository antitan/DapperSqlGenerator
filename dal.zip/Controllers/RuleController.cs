﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RuleController : ControllerBase
    {
        private readonly ILogger<RuleController> logger;
        private readonly IRuleService ruleService;

        public RuleController(IRuleService ruleService, ILogger<RuleController> logger)
        {
            this.ruleService = ruleService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new Rule entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(RuleRequestAddDto ruleRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = ruleRequestAddDto.ToEntity();
                await ruleService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in ruleController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update Rule entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(RuleRequestUpdateDto ruleRequestUpdateDto)
        {
            try
            {
                var rule = await ruleService.GetByIdAsync(ruleRequestUpdateDto.Id);
                if (rule == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await ruleService.UpdateAsync(rule);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in ruleController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete Rule entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var rule = await ruleService.GetByIdAsync(id);
                if (rule == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await ruleService.DeleteAsync(rule);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in ruleController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get Rule by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(RuleResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            RuleResponseGetByIdDto? ruleResponseGetByIdDto = null;
            try
            {
                var entity = await ruleService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                ruleResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in RuleController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(ruleResponseGetByIdDto);
        }



    }

}
