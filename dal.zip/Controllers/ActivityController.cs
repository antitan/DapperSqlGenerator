﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityController : ControllerBase
    {
        private readonly ILogger<ActivityController> logger;
        private readonly IActivityService activityService;

        public ActivityController(IActivityService activityService, ILogger<ActivityController> logger)
        {
            this.activityService = activityService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new Activity entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(ActivityRequestAddDto activityRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = activityRequestAddDto.ToEntity();
                await activityService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in activityController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update Activity entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(ActivityRequestUpdateDto activityRequestUpdateDto)
        {
            try
            {
                var activity = await activityService.GetByIdAsync(activityRequestUpdateDto.Id);
                if (activity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await activityService.UpdateAsync(activity);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in activityController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete Activity entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var activity = await activityService.GetByIdAsync(id);
                if (activity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await activityService.DeleteAsync(activity);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in activityController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get Activity by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ActivityResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            ActivityResponseGetByIdDto? activityResponseGetByIdDto = null;
            try
            {
                var entity = await activityService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                activityResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in ActivityController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(activityResponseGetByIdDto);
        }



    }

}
