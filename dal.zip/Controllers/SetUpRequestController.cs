﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SetUpRequestController : ControllerBase
    {
        private readonly ILogger<SetUpRequestController> logger;
        private readonly ISetUpRequestService setUpRequestService;

        public SetUpRequestController(ISetUpRequestService setUpRequestService, ILogger<SetUpRequestController> logger)
        {
            this.setUpRequestService = setUpRequestService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new SetUpRequest entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(SetUpRequestRequestAddDto setUpRequestRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = setUpRequestRequestAddDto.ToEntity();
                await setUpRequestService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in setUpRequestController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update SetUpRequest entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(SetUpRequestRequestUpdateDto setUpRequestRequestUpdateDto)
        {
            try
            {
                var setUpRequest = await setUpRequestService.GetByIdAsync(setUpRequestRequestUpdateDto.Id);
                if (setUpRequest == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await setUpRequestService.UpdateAsync(setUpRequest);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in setUpRequestController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete SetUpRequest entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var setUpRequest = await setUpRequestService.GetByIdAsync(id);
                if (setUpRequest == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await setUpRequestService.DeleteAsync(setUpRequest);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in setUpRequestController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get SetUpRequest by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(SetUpRequestResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            SetUpRequestResponseGetByIdDto? setUpRequestResponseGetByIdDto = null;
            try
            {
                var entity = await setUpRequestService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                setUpRequestResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in SetUpRequestController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(setUpRequestResponseGetByIdDto);
        }



    }

}
