﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentActivityController : ControllerBase
    {
        private readonly ILogger<PaymentActivityController> logger;
        private readonly IPaymentActivityService paymentActivityService;

        public PaymentActivityController(IPaymentActivityService paymentActivityService, ILogger<PaymentActivityController> logger)
        {
            this.paymentActivityService = paymentActivityService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new PaymentActivity entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(PaymentActivityRequestAddDto paymentActivityRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = paymentActivityRequestAddDto.ToEntity();
                await paymentActivityService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in paymentActivityController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update PaymentActivity entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(PaymentActivityRequestUpdateDto paymentActivityRequestUpdateDto)
        {
            try
            {
                var paymentActivity = await paymentActivityService.GetByIdAsync(paymentActivityRequestUpdateDto.Id);
                if (paymentActivity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await paymentActivityService.UpdateAsync(paymentActivity);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in paymentActivityController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete PaymentActivity entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var paymentActivity = await paymentActivityService.GetByIdAsync(id);
                if (paymentActivity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await paymentActivityService.DeleteAsync(paymentActivity);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in paymentActivityController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get PaymentActivity by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(PaymentActivityResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            PaymentActivityResponseGetByIdDto? paymentActivityResponseGetByIdDto = null;
            try
            {
                var entity = await paymentActivityService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                paymentActivityResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in PaymentActivityController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(paymentActivityResponseGetByIdDto);
        }



    }

}
