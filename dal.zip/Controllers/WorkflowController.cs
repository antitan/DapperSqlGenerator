﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class WorkflowController : ControllerBase
    {
        private readonly ILogger<WorkflowController> logger;
        private readonly IWorkflowService workflowService;

        public WorkflowController(IWorkflowService workflowService, ILogger<WorkflowController> logger)
        {
            this.workflowService = workflowService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new Workflow entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(WorkflowRequestAddDto workflowRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = workflowRequestAddDto.ToEntity();
                await workflowService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in workflowController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update Workflow entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(WorkflowRequestUpdateDto workflowRequestUpdateDto)
        {
            try
            {
                var workflow = await workflowService.GetByIdAsync(workflowRequestUpdateDto.Id);
                if (workflow == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await workflowService.UpdateAsync(workflow);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in workflowController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete Workflow entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var workflow = await workflowService.GetByIdAsync(id);
                if (workflow == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await workflowService.DeleteAsync(workflow);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in workflowController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get Workflow by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(WorkflowResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            WorkflowResponseGetByIdDto? workflowResponseGetByIdDto = null;
            try
            {
                var entity = await workflowService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                workflowResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in WorkflowController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(workflowResponseGetByIdDto);
        }



    }

}
