﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityWorkflowController : ControllerBase
    {
        private readonly ILogger<ActivityWorkflowController> logger;
        private readonly IActivityWorkflowService activityWorkflowService;

        public ActivityWorkflowController(IActivityWorkflowService activityWorkflowService, ILogger<ActivityWorkflowController> logger)
        {
            this.activityWorkflowService = activityWorkflowService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new ActivityWorkflow entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(ActivityWorkflowRequestAddDto activityWorkflowRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = activityWorkflowRequestAddDto.ToEntity();
                await activityWorkflowService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in activityWorkflowController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update ActivityWorkflow entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(ActivityWorkflowRequestUpdateDto activityWorkflowRequestUpdateDto)
        {
            try
            {
                var activityWorkflow = await activityWorkflowService.GetByIdAsync(activityWorkflowRequestUpdateDto.Id);
                if (activityWorkflow == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await activityWorkflowService.UpdateAsync(activityWorkflow);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in activityWorkflowController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete ActivityWorkflow entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var activityWorkflow = await activityWorkflowService.GetByIdAsync(id);
                if (activityWorkflow == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await activityWorkflowService.DeleteAsync(activityWorkflow);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in activityWorkflowController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get ActivityWorkflow by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ActivityWorkflowResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            ActivityWorkflowResponseGetByIdDto? activityWorkflowResponseGetByIdDto = null;
            try
            {
                var entity = await activityWorkflowService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                activityWorkflowResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in ActivityWorkflowController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(activityWorkflowResponseGetByIdDto);
        }



    }

}
