﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RestrictionValueController : ControllerBase
    {
        private readonly ILogger<RestrictionValueController> logger;
        private readonly IRestrictionValueService restrictionValueService;

        public RestrictionValueController(IRestrictionValueService restrictionValueService, ILogger<RestrictionValueController> logger)
        {
            this.restrictionValueService = restrictionValueService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new RestrictionValue entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(RestrictionValueRequestAddDto restrictionValueRequestAddDto)
        {
            System.Guid id = 0;
            try
            {
                var entity = restrictionValueRequestAddDto.ToEntity();
                await restrictionValueService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in restrictionValueController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update RestrictionValue entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(RestrictionValueRequestUpdateDto restrictionValueRequestUpdateDto)
        {
            try
            {
                var restrictionValue = await restrictionValueService.GetByIdAsync(restrictionValueRequestUpdateDto.Id);
                if (restrictionValue == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await restrictionValueService.UpdateAsync(restrictionValue);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in restrictionValueController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete RestrictionValue entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(System.Guid id)
        {
            try
            {
                var restrictionValue = await restrictionValueService.GetByIdAsync(id);
                if (restrictionValue == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await restrictionValueService.DeleteAsync(restrictionValue);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in restrictionValueController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get RestrictionValue by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(RestrictionValueResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(System.Guid id)
        {
            RestrictionValueResponseGetByIdDto? restrictionValueResponseGetByIdDto = null;
            try
            {
                var entity = await restrictionValueService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                restrictionValueResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in RestrictionValueController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(restrictionValueResponseGetByIdDto);
        }



    }

}
