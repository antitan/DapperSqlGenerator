﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.WebApi.Response;
using MyProject.Services;
using Dakota.Contacts.WebApi.Mappers;

namespace Dakota.Contacts.WebApi.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SetUpRequestStatusController : ControllerBase
    {
        private readonly ILogger<SetUpRequestStatusController> logger;
        private readonly ISetUpRequestStatusService setUpRequestStatusService;

        public SetUpRequestStatusController(ISetUpRequestStatusService setUpRequestStatusService, ILogger<SetUpRequestStatusController> logger)
        {
            this.setUpRequestStatusService = setUpRequestStatusService;
            this.logger = logger;
        }


        /// <summary>
        /// Add new SetUpRequestStatus entity
        /// </summary>
        [HttpPost("add")]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddAsync(SetUpRequestStatusRequestAddDto setUpRequestStatusRequestAddDto)
        {
            byte id = 0;
            try
            {
                var entity = setUpRequestStatusRequestAddDto.ToEntity();
                await setUpRequestStatusService.InsertAsync(entity);
                id = entity.Id;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in setUpRequestStatusController.Add method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(id);
        }

        /// <summary>
        /// Update SetUpRequestStatus entity
        /// </summary>
        [HttpPost("udpate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateAsync(SetUpRequestStatusRequestUpdateDto setUpRequestStatusRequestUpdateDto)
        {
            try
            {
                var setUpRequestStatus = await setUpRequestStatusService.GetByIdAsync(setUpRequestStatusRequestUpdateDto.Id);
                if (setUpRequestStatus == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await setUpRequestStatusService.UpdateAsync(setUpRequestStatus);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in setUpRequestStatusController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Delete SetUpRequestStatus entity
        /// </summary>
        [HttpDelete("delete/{id}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeleteAsync(byte id)
        {
            try
            {
                var setUpRequestStatus = await setUpRequestStatusService.GetByIdAsync(id);
                if (setUpRequestStatus == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                await setUpRequestStatusService.DeleteAsync(setUpRequestStatus);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in setUpRequestStatusController.Update method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok();
        }


        /// <summary>
        /// Get all SetUpRequestStatus entities
        /// </summary>
        [HttpGet("all")]
        [ProducesResponseType(typeof(IList<TranslatedItemDto>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetAllAsync()
        {
            IList<TranslatedItemDto>? enumItems = null;
            try
            {
                var entities = await translationService.GetTranslatedItems("scope");
                if (entities != null && entities.Any())
                {
                    var translatedItems = entities.Select(x => x.ToTranslatedItemDto());
                    enumItems = translatedItems.ToList();
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in SetUpRequestStatusController.Get method");
                return StatusCode((int)HttpStatusCode.InternalServerError, " internal error ");
            }
            return Ok(enumItems);
        }

        /// <summary>
        /// Get SetUpRequestStatus by Pk
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(SetUpRequestStatusResponseGetByIdDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetByIdAsync(byte id)
        {
            SetUpRequestStatusResponseGetByIdDto? setUpRequestStatusResponseGetByIdDto = null;
            try
            {
                var entity = await setUpRequestStatusService.GetByIdAsync(id);
                if (entity == null)
                {
                    return StatusCode((int)HttpStatusCode.NotFound);
                }
                setUpRequestStatusResponseGetByIdDto = entity.ToGetByIdDto();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Problem in SetUpRequestStatusController.GetByIdAsync method");
                return StatusCode((int)HttpStatusCode.InternalServerError, "internal error ");
            }
            return Ok(setUpRequestStatusResponseGetByIdDto);
        }



    }

}
