﻿using System.Linq.Expressions;
using MyProject.Common.Pagination;
using MyProject.Business.DataModel;

namespace MyProject.Services
{
    public interface IActivityWorkflowService
    {
        Task<PagedResults<ActivityWorkflow>> GetPaginatedAsync(Expression<Func<ActivityWorkflow, bool>>? criteria = null, Expression<Func<ActivityWorkflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<ActivityWorkflow?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<ActivityWorkflow>?> GetByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria);
        Task<bool> InsertAsync(ActivityWorkflow activityWorkflow);
        Task UpdateAsync(ActivityWorkflow activityWorkflow);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria);

    }
}
