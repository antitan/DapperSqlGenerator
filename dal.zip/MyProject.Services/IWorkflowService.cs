﻿using System.Linq.Expressions;
using MyProject.Common.Pagination;
using MyProject.Business.DataModel;

namespace MyProject.Services
{
    public interface IWorkflowService
    {
        Task<PagedResults<Workflow>> GetPaginatedAsync(Expression<Func<Workflow, bool>>? criteria = null, Expression<Func<Workflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<Workflow?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<Workflow>?> GetByExpressionAsync(Expression<Func<Workflow, bool>> criteria);
        Task<bool> InsertAsync(Workflow workflow);
        Task UpdateAsync(Workflow workflow);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<Workflow, bool>> criteria);

    }
}
