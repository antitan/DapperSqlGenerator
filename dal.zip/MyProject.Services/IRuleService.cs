﻿using System.Linq.Expressions;
using MyProject.Common.Pagination;
using MyProject.Business.DataModel;

namespace MyProject.Services
{
    public interface IRuleService
    {
        Task<PagedResults<Rule>> GetPaginatedAsync(Expression<Func<Rule, bool>>? criteria = null, Expression<Func<Rule, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<Rule?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<Rule>?> GetByExpressionAsync(Expression<Func<Rule, bool>> criteria);
        Task<bool> InsertAsync(Rule rule);
        Task UpdateAsync(Rule rule);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<Rule, bool>> criteria);

    }
}
