﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class WorkflowService : IWorkflowService
    {
        private readonly IWorkflowRepository workflowRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<WorkflowService> logger;

        public WorkflowService(IWorkflowRepository workflowRepository, ICacheManager cacheManager, ILogger<WorkflowService> logger)
        {
            this.workflowRepository = workflowRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert Workflow
        /// </summary>
        public async Task<bool> InsertAsync(Workflow workflow)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await workflowRepository.InsertAsync(workflow);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert Workflow {JsonSerializer.Serialize(workflow, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update Workflow
        /// </summary>
        public async Task UpdateAsync(Workflow workflow)
        {
            try
            {
                await workflowRepository.UpdateAsync(workflow);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update Workflow {JsonSerializer.Serialize(workflow, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete Workflow
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await workflowRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete Workflow System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated Workflow
        /// </summary>
        public async Task<PagedResults<Workflow>> GetPaginatedAsync(Expression<Func<Workflow, bool>>? criteria = null, Expression<Func<Workflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<Workflow> result = null;
            try
            {
                result = await workflowRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync Workflow  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get Workflow by PK
        /// </summary>
        public async Task<Workflow?> GetByIdAsync(System.Guid id)
        {
            Workflow? result = null;
            try
            {
                result = await workflowRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById Workflow  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get Workflow by Expression
        /// </summary>
        public async Task<IEnumerable<Workflow>?> GetByExpressionAsync(Expression<Func<Workflow, bool>> criteria)
        {
            IEnumerable<Workflow>? result = null;
            try
            {
                result = await workflowRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for Workflow Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete Workflow by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<Workflow, bool>> criteria)
        {
            try
            {
                await workflowRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for Workflow Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
