﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class RestrictionValueService : IRestrictionValueService
    {
        private readonly IRestrictionValueRepository restrictionValueRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<RestrictionValueService> logger;

        public RestrictionValueService(IRestrictionValueRepository restrictionValueRepository, ICacheManager cacheManager, ILogger<RestrictionValueService> logger)
        {
            this.restrictionValueRepository = restrictionValueRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert RestrictionValue
        /// </summary>
        public async Task<bool> InsertAsync(RestrictionValue restrictionValue)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await restrictionValueRepository.InsertAsync(restrictionValue);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert RestrictionValue {JsonSerializer.Serialize(restrictionValue, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update RestrictionValue
        /// </summary>
        public async Task UpdateAsync(RestrictionValue restrictionValue)
        {
            try
            {
                await restrictionValueRepository.UpdateAsync(restrictionValue);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update RestrictionValue {JsonSerializer.Serialize(restrictionValue, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete RestrictionValue
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await restrictionValueRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete RestrictionValue System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated RestrictionValue
        /// </summary>
        public async Task<PagedResults<RestrictionValue>> GetPaginatedAsync(Expression<Func<RestrictionValue, bool>>? criteria = null, Expression<Func<RestrictionValue, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<RestrictionValue> result = null;
            try
            {
                result = await restrictionValueRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync RestrictionValue  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get RestrictionValue by PK
        /// </summary>
        public async Task<RestrictionValue?> GetByIdAsync(System.Guid id)
        {
            RestrictionValue? result = null;
            try
            {
                result = await restrictionValueRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById RestrictionValue  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get RestrictionValue by Expression
        /// </summary>
        public async Task<IEnumerable<RestrictionValue>?> GetByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria)
        {
            IEnumerable<RestrictionValue>? result = null;
            try
            {
                result = await restrictionValueRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for RestrictionValue Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete RestrictionValue by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria)
        {
            try
            {
                await restrictionValueRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for RestrictionValue Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
