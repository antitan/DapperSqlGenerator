﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class RestrictionListService : IRestrictionListService
    {
        private readonly IRestrictionListRepository restrictionListRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<RestrictionListService> logger;

        public RestrictionListService(IRestrictionListRepository restrictionListRepository, ICacheManager cacheManager, ILogger<RestrictionListService> logger)
        {
            this.restrictionListRepository = restrictionListRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert RestrictionList
        /// </summary>
        public async Task<bool> InsertAsync(RestrictionList restrictionList)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await restrictionListRepository.InsertAsync(restrictionList);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert RestrictionList {JsonSerializer.Serialize(restrictionList, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update RestrictionList
        /// </summary>
        public async Task UpdateAsync(RestrictionList restrictionList)
        {
            try
            {
                await restrictionListRepository.UpdateAsync(restrictionList);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update RestrictionList {JsonSerializer.Serialize(restrictionList, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete RestrictionList
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await restrictionListRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete RestrictionList System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated RestrictionList
        /// </summary>
        public async Task<PagedResults<RestrictionList>> GetPaginatedAsync(Expression<Func<RestrictionList, bool>>? criteria = null, Expression<Func<RestrictionList, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<RestrictionList> result = null;
            try
            {
                result = await restrictionListRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync RestrictionList  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get RestrictionList by PK
        /// </summary>
        public async Task<RestrictionList?> GetByIdAsync(System.Guid id)
        {
            RestrictionList? result = null;
            try
            {
                result = await restrictionListRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById RestrictionList  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get RestrictionList by Expression
        /// </summary>
        public async Task<IEnumerable<RestrictionList>?> GetByExpressionAsync(Expression<Func<RestrictionList, bool>> criteria)
        {
            IEnumerable<RestrictionList>? result = null;
            try
            {
                result = await restrictionListRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for RestrictionList Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete RestrictionList by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<RestrictionList, bool>> criteria)
        {
            try
            {
                await restrictionListRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for RestrictionList Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
