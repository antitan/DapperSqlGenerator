﻿using System.Linq.Expressions;
using MyProject.Common.Pagination;
using MyProject.Business.DataModel;

namespace MyProject.Services
{
    public interface IActivityService
    {
        Task<PagedResults<Activity>> GetPaginatedAsync(Expression<Func<Activity, bool>>? criteria = null, Expression<Func<Activity, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<Activity?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<Activity>?> GetByExpressionAsync(Expression<Func<Activity, bool>> criteria);
        Task<bool> InsertAsync(Activity activity);
        Task UpdateAsync(Activity activity);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<Activity, bool>> criteria);

    }
}
