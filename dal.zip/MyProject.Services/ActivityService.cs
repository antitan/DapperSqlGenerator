﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class ActivityService : IActivityService
    {
        private readonly IActivityRepository activityRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<ActivityService> logger;

        public ActivityService(IActivityRepository activityRepository, ICacheManager cacheManager, ILogger<ActivityService> logger)
        {
            this.activityRepository = activityRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert Activity
        /// </summary>
        public async Task<bool> InsertAsync(Activity activity)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await activityRepository.InsertAsync(activity);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert Activity {JsonSerializer.Serialize(activity, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update Activity
        /// </summary>
        public async Task UpdateAsync(Activity activity)
        {
            try
            {
                await activityRepository.UpdateAsync(activity);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update Activity {JsonSerializer.Serialize(activity, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete Activity
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await activityRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete Activity System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated Activity
        /// </summary>
        public async Task<PagedResults<Activity>> GetPaginatedAsync(Expression<Func<Activity, bool>>? criteria = null, Expression<Func<Activity, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<Activity> result = null;
            try
            {
                result = await activityRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync Activity  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get Activity by PK
        /// </summary>
        public async Task<Activity?> GetByIdAsync(System.Guid id)
        {
            Activity? result = null;
            try
            {
                result = await activityRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById Activity  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get Activity by Expression
        /// </summary>
        public async Task<IEnumerable<Activity>?> GetByExpressionAsync(Expression<Func<Activity, bool>> criteria)
        {
            IEnumerable<Activity>? result = null;
            try
            {
                result = await activityRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for Activity Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete Activity by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<Activity, bool>> criteria)
        {
            try
            {
                await activityRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for Activity Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
