﻿using System.Linq.Expressions;
using MyProject.Common.Pagination;
using MyProject.Business.DataModel;

namespace MyProject.Services
{
    public interface IPaymentActivityService
    {
        Task<PagedResults<PaymentActivity>> GetPaginatedAsync(Expression<Func<PaymentActivity, bool>>? criteria = null, Expression<Func<PaymentActivity, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<PaymentActivity?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<PaymentActivity>?> GetByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria);
        Task<bool> InsertAsync(PaymentActivity paymentActivity);
        Task UpdateAsync(PaymentActivity paymentActivity);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria);

    }
}
