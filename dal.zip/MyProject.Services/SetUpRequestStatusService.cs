﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class SetUpRequestStatusService : ISetUpRequestStatusService
    {
        private readonly ISetUpRequestStatusRepository setUpRequestStatusRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<SetUpRequestStatusService> logger;

        public SetUpRequestStatusService(ISetUpRequestStatusRepository setUpRequestStatusRepository, ICacheManager cacheManager, ILogger<SetUpRequestStatusService> logger)
        {
            this.setUpRequestStatusRepository = setUpRequestStatusRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert SetUpRequestStatus
        /// </summary>
        public async Task<byte> InsertAsync(SetUpRequestStatus setUpRequestStatus)
        {
            byte result = (byte)ReflexionHelper.GetDefaultValue(typeof(byte));
            try
            {
                result = await setUpRequestStatusRepository.InsertAsync(setUpRequestStatus);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert SetUpRequestStatus {JsonSerializer.Serialize(setUpRequestStatus, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update SetUpRequestStatus
        /// </summary>
        public async Task UpdateAsync(SetUpRequestStatus setUpRequestStatus)
        {
            try
            {
                await setUpRequestStatusRepository.UpdateAsync(setUpRequestStatus);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update SetUpRequestStatus {JsonSerializer.Serialize(setUpRequestStatus, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete SetUpRequestStatus
        /// </summary>
        public async Task DeleteByIdAsync(byte id)
        {
            try
            {
                await setUpRequestStatusRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete SetUpRequestStatus byte id  error : {ex}");
            }
        }


        /// <summary>
        /// Get all SetUpRequestStatus
        /// </summary>
        public async Task<IEnumerable<SetUpRequestStatus>?> GetAllAsync()
        {
            IEnumerable<SetUpRequestStatus>? result = null;
            try
            {
                if (!cacheManager.IsSet(CacheDataConstants.SetUpRequestStatusAllCacheKey))
                {
                    result = await setUpRequestStatusRepository.GetAllAsync();
                    cacheManager.Add(CacheDataConstants.SetUpRequestStatusAllCacheKey, result);
                }
                else
                    return cacheManager.Get<IEnumerable<SetUpRequestStatus>>(CacheDataConstants.SetUpRequestStatusAllCacheKey);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to get all SetUpRequestStatus  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get paginated SetUpRequestStatus
        /// </summary>
        public async Task<PagedResults<SetUpRequestStatus>> GetPaginatedAsync(Expression<Func<SetUpRequestStatus, bool>>? criteria = null, Expression<Func<SetUpRequestStatus, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<SetUpRequestStatus> result = null;
            try
            {
                result = await setUpRequestStatusRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync SetUpRequestStatus  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get SetUpRequestStatus by PK
        /// </summary>
        public async Task<SetUpRequestStatus?> GetByIdAsync(byte id)
        {
            SetUpRequestStatus? result = null;
            try
            {
                result = await setUpRequestStatusRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById SetUpRequestStatus  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get SetUpRequestStatus by Expression
        /// </summary>
        public async Task<IEnumerable<SetUpRequestStatus>?> GetByExpressionAsync(Expression<Func<SetUpRequestStatus, bool>> criteria)
        {
            IEnumerable<SetUpRequestStatus>? result = null;
            try
            {
                result = await setUpRequestStatusRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for SetUpRequestStatus Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete SetUpRequestStatus by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<SetUpRequestStatus, bool>> criteria)
        {
            try
            {
                await setUpRequestStatusRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for SetUpRequestStatus Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
