﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class RuleService : IRuleService
    {
        private readonly IRuleRepository ruleRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<RuleService> logger;

        public RuleService(IRuleRepository ruleRepository, ICacheManager cacheManager, ILogger<RuleService> logger)
        {
            this.ruleRepository = ruleRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert Rule
        /// </summary>
        public async Task<bool> InsertAsync(Rule rule)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await ruleRepository.InsertAsync(rule);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert Rule {JsonSerializer.Serialize(rule, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update Rule
        /// </summary>
        public async Task UpdateAsync(Rule rule)
        {
            try
            {
                await ruleRepository.UpdateAsync(rule);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update Rule {JsonSerializer.Serialize(rule, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete Rule
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await ruleRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete Rule System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated Rule
        /// </summary>
        public async Task<PagedResults<Rule>> GetPaginatedAsync(Expression<Func<Rule, bool>>? criteria = null, Expression<Func<Rule, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<Rule> result = null;
            try
            {
                result = await ruleRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync Rule  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get Rule by PK
        /// </summary>
        public async Task<Rule?> GetByIdAsync(System.Guid id)
        {
            Rule? result = null;
            try
            {
                result = await ruleRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById Rule  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get Rule by Expression
        /// </summary>
        public async Task<IEnumerable<Rule>?> GetByExpressionAsync(Expression<Func<Rule, bool>> criteria)
        {
            IEnumerable<Rule>? result = null;
            try
            {
                result = await ruleRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for Rule Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete Rule by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<Rule, bool>> criteria)
        {
            try
            {
                await ruleRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for Rule Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
