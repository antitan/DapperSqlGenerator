﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class ActivityWorkflowService : IActivityWorkflowService
    {
        private readonly IActivityWorkflowRepository activityWorkflowRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<ActivityWorkflowService> logger;

        public ActivityWorkflowService(IActivityWorkflowRepository activityWorkflowRepository, ICacheManager cacheManager, ILogger<ActivityWorkflowService> logger)
        {
            this.activityWorkflowRepository = activityWorkflowRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert ActivityWorkflow
        /// </summary>
        public async Task<bool> InsertAsync(ActivityWorkflow activityWorkflow)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await activityWorkflowRepository.InsertAsync(activityWorkflow);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert ActivityWorkflow {JsonSerializer.Serialize(activityWorkflow, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update ActivityWorkflow
        /// </summary>
        public async Task UpdateAsync(ActivityWorkflow activityWorkflow)
        {
            try
            {
                await activityWorkflowRepository.UpdateAsync(activityWorkflow);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update ActivityWorkflow {JsonSerializer.Serialize(activityWorkflow, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete ActivityWorkflow
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await activityWorkflowRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete ActivityWorkflow System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated ActivityWorkflow
        /// </summary>
        public async Task<PagedResults<ActivityWorkflow>> GetPaginatedAsync(Expression<Func<ActivityWorkflow, bool>>? criteria = null, Expression<Func<ActivityWorkflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<ActivityWorkflow> result = null;
            try
            {
                result = await activityWorkflowRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync ActivityWorkflow  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get ActivityWorkflow by PK
        /// </summary>
        public async Task<ActivityWorkflow?> GetByIdAsync(System.Guid id)
        {
            ActivityWorkflow? result = null;
            try
            {
                result = await activityWorkflowRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById ActivityWorkflow  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get ActivityWorkflow by Expression
        /// </summary>
        public async Task<IEnumerable<ActivityWorkflow>?> GetByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria)
        {
            IEnumerable<ActivityWorkflow>? result = null;
            try
            {
                result = await activityWorkflowRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for ActivityWorkflow Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete ActivityWorkflow by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria)
        {
            try
            {
                await activityWorkflowRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for ActivityWorkflow Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
