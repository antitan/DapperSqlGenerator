﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class SetUpRequestService : ISetUpRequestService
    {
        private readonly ISetUpRequestRepository setUpRequestRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<SetUpRequestService> logger;

        public SetUpRequestService(ISetUpRequestRepository setUpRequestRepository, ICacheManager cacheManager, ILogger<SetUpRequestService> logger)
        {
            this.setUpRequestRepository = setUpRequestRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert SetUpRequest
        /// </summary>
        public async Task<bool> InsertAsync(SetUpRequest setUpRequest)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await setUpRequestRepository.InsertAsync(setUpRequest);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert SetUpRequest {JsonSerializer.Serialize(setUpRequest, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update SetUpRequest
        /// </summary>
        public async Task UpdateAsync(SetUpRequest setUpRequest)
        {
            try
            {
                await setUpRequestRepository.UpdateAsync(setUpRequest);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update SetUpRequest {JsonSerializer.Serialize(setUpRequest, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete SetUpRequest
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await setUpRequestRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete SetUpRequest System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated SetUpRequest
        /// </summary>
        public async Task<PagedResults<SetUpRequest>> GetPaginatedAsync(Expression<Func<SetUpRequest, bool>>? criteria = null, Expression<Func<SetUpRequest, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<SetUpRequest> result = null;
            try
            {
                result = await setUpRequestRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync SetUpRequest  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get SetUpRequest by PK
        /// </summary>
        public async Task<SetUpRequest?> GetByIdAsync(System.Guid id)
        {
            SetUpRequest? result = null;
            try
            {
                result = await setUpRequestRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById SetUpRequest  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get SetUpRequest by Expression
        /// </summary>
        public async Task<IEnumerable<SetUpRequest>?> GetByExpressionAsync(Expression<Func<SetUpRequest, bool>> criteria)
        {
            IEnumerable<SetUpRequest>? result = null;
            try
            {
                result = await setUpRequestRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for SetUpRequest Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete SetUpRequest by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<SetUpRequest, bool>> criteria)
        {
            try
            {
                await setUpRequestRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for SetUpRequest Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
