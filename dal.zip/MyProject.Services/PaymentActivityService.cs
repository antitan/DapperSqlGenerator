﻿using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Linq.Expressions;
using MyProject.Common.Helpers;
using MyProject.Common.Pagination;
using MyProject.Common.Constants;
using MyProject.Common.Cache;
using MyProject.Business.DataModel;
using MyProject.Repositories;

namespace MyProject.Services
{

    public class PaymentActivityService : IPaymentActivityService
    {
        private readonly IPaymentActivityRepository paymentActivityRepository;
        private readonly ICacheManager cacheManager;
        private readonly ILogger<PaymentActivityService> logger;

        public PaymentActivityService(IPaymentActivityRepository paymentActivityRepository, ICacheManager cacheManager, ILogger<PaymentActivityService> logger)
        {
            this.paymentActivityRepository = paymentActivityRepository;
            this.cacheManager = cacheManager;
            this.logger = logger;
        }


        /// <summary>
        /// Insert PaymentActivity
        /// </summary>
        public async Task<bool> InsertAsync(PaymentActivity paymentActivity)
        {
            bool result = (bool)ReflexionHelper.GetDefaultValue(typeof(bool));
            try
            {
                result = await paymentActivityRepository.InsertAsync(paymentActivity);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to insert PaymentActivity {JsonSerializer.Serialize(paymentActivity, JsonHelper.ConfigureDefaultSerialization())}   error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Update PaymentActivity
        /// </summary>
        public async Task UpdateAsync(PaymentActivity paymentActivity)
        {
            try
            {
                await paymentActivityRepository.UpdateAsync(paymentActivity);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to update PaymentActivity {JsonSerializer.Serialize(paymentActivity, JsonHelper.ConfigureDefaultSerialization())}  error : {ex}");
            }
        }


        /// <summary>
        /// Delete PaymentActivity
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            try
            {
                await paymentActivityRepository.DeleteByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to delete PaymentActivity System.Guid id  error : {ex}");
            }
        }


        /// <summary>
        /// Get paginated PaymentActivity
        /// </summary>
        public async Task<PagedResults<PaymentActivity>> GetPaginatedAsync(Expression<Func<PaymentActivity, bool>>? criteria = null, Expression<Func<PaymentActivity, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            PagedResults<PaymentActivity> result = null;
            try
            {
                result = await paymentActivityRepository.GetPaginatedAsync(criteria, orderByExpression, page, pageSize);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetAllPaginatedAsync PaymentActivity  error : {ex}");
            }
            return result;
        }

        /// <summary>
        /// Get PaymentActivity by PK
        /// </summary>
        public async Task<PaymentActivity?> GetByIdAsync(System.Guid id)
        {
            PaymentActivity? result = null;
            try
            {
                result = await paymentActivityRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetById PaymentActivity  error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Get PaymentActivity by Expression
        /// </summary>
        public async Task<IEnumerable<PaymentActivity>?> GetByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria)
        {
            IEnumerable<PaymentActivity>? result = null;
            try
            {
                result = await paymentActivityRepository.GetByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to GetByExpressionAsync for PaymentActivity Criter=[criteria.ToString() - criteria.ToMSSqlString()] error : {ex}");
            }
            return result;
        }


        /// <summary>
        /// Delete PaymentActivity by Expression
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria)
        {
            try
            {
                await paymentActivityRepository.DeleteByExpressionAsync(criteria);
            }
            catch (Exception ex)
            {
                logger.LogError($" Problem to DeleteByExpressionAsync for PaymentActivity Criter=[criteria.ToString() - criteria.ToMSSqlString()]   error : {ex}");
            }
        }



    }

}
