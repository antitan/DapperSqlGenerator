﻿using System.Linq.Expressions;
using MyProject.Common.Pagination;
using MyProject.Business.DataModel;

namespace MyProject.Services
{
    public interface IRestrictionValueService
    {
        Task<PagedResults<RestrictionValue>> GetPaginatedAsync(Expression<Func<RestrictionValue, bool>>? criteria = null, Expression<Func<RestrictionValue, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<RestrictionValue?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<RestrictionValue>?> GetByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria);
        Task<bool> InsertAsync(RestrictionValue restrictionValue);
        Task UpdateAsync(RestrictionValue restrictionValue);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria);

    }
}
