﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface IRestrictionValueRepository
    {
        Task<IEnumerable<RestrictionValue>?> GetAllAsync();
        Task<PagedResults<RestrictionValue>> GetPaginatedAsync(Expression<Func<RestrictionValue, bool>>? criteria = null, Expression<Func<RestrictionValue, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<RestrictionValue?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<RestrictionValue>?> GetByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria);
        Task<bool> InsertAsync(RestrictionValue restrictionValue);
        Task UpdateAsync(RestrictionValue restrictionValue);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria);
        Task<bool> InsertAsyncTransaction(RestrictionValue restrictionValue, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(RestrictionValue restrictionValue, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction);

    }
}
