﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class ActivityRepository : IActivityRepository
    {

        private readonly string? connectionString;

        public ActivityRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all Activity
        /// </summary>
        public async Task<IEnumerable<Activity>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<Activity>("SELECT  [Id], [TypeCode], [CreatedBy], [CreatedOn], [Origin], [Channel], [Ip], [FingerPrint], [Result], [ChallengeResult], [UpdateBy], [UpdateOn]  FROM [dbo].[Activity] ");
                return entities;
            }
        }

        /// <summary>
        /// Get Activity by PK
        /// </summary>
        public async Task<Activity?> GetByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<Activity>("SELECT  [Id], [TypeCode], [CreatedBy], [CreatedOn], [Origin], [Channel], [Ip], [FingerPrint], [Result], [ChallengeResult], [UpdateBy], [UpdateOn]  FROM [dbo].[Activity]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get Activity by expression 
        /// </summary>
        public async Task<IEnumerable<Activity>?> GetByExpressionAsync(Expression<Func<Activity, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [TypeCode], [CreatedBy], [CreatedOn], [Origin], [Channel], [Ip], [FingerPrint], [Result], [ChallengeResult], [UpdateBy], [UpdateOn] FROM [dbo].[Activity] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<Activity>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated Activity
        /// </summary>
        public async Task<PagedResults<Activity>> GetPaginatedAsync(Expression<Func<Activity, bool>>? criteria, Expression<Func<Activity, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<Activity>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [TypeCode], [CreatedBy], [CreatedOn], [Origin], [Channel], [Ip], [FingerPrint], [Result], [ChallengeResult], [UpdateBy], [UpdateOn] FROM [dbo].[Activity] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[Activity] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<Activity>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert Activity
        /// </summary>
        public async Task<bool> InsertAsync(Activity activity)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activity.Id);
                p.Add("@TypeCode", activity.TypeCode);
                p.Add("@CreatedBy", activity.CreatedBy);
                p.Add("@CreatedOn", activity.CreatedOn);
                p.Add("@Origin", activity.Origin);
                p.Add("@Channel", activity.Channel);
                p.Add("@Ip", activity.Ip);
                p.Add("@FingerPrint", activity.FingerPrint);
                p.Add("@Result", activity.Result);
                p.Add("@ChallengeResult", activity.ChallengeResult);
                p.Add("@UpdateBy", activity.UpdateBy);
                p.Add("@UpdateOn", activity.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[Activity] ([Id], [TypeCode], [CreatedBy], [CreatedOn], [Origin], [Channel], [Ip], [FingerPrint], [Result], [ChallengeResult], [UpdateBy], [UpdateOn])  VALUES (@Id, @TypeCode, @CreatedBy, @CreatedOn, @Origin, @Channel, @Ip, @FingerPrint, @Result, @ChallengeResult, @UpdateBy, @UpdateOn)", p);

                return true;
            }

        }


        /// <summary>
        /// Update Activity
        /// </summary>
        public async Task UpdateAsync(Activity activity)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activity.Id);
                p.Add("@TypeCode", activity.TypeCode);
                p.Add("@CreatedBy", activity.CreatedBy);
                p.Add("@CreatedOn", activity.CreatedOn);
                p.Add("@Origin", activity.Origin);
                p.Add("@Channel", activity.Channel);
                p.Add("@Ip", activity.Ip);
                p.Add("@FingerPrint", activity.FingerPrint);
                p.Add("@Result", activity.Result);
                p.Add("@ChallengeResult", activity.ChallengeResult);
                p.Add("@UpdateBy", activity.UpdateBy);
                p.Add("@UpdateOn", activity.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[Activity]  SET [Id] = @Id, [TypeCode] = @TypeCode, [CreatedBy] = @CreatedBy, [CreatedOn] = @CreatedOn, [Origin] = @Origin, [Channel] = @Channel, [Ip] = @Ip, [FingerPrint] = @FingerPrint, [Result] = @Result, [ChallengeResult] = @ChallengeResult, [UpdateBy] = @UpdateBy, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete Activity inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[Activity] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete Activity
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<Activity, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[Activity] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert Activity inside a Transaction
        /// </summary>
        public async Task<bool> InsertAsyncTransaction(Activity activity, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activity.Id);
                p.Add("@TypeCode", activity.TypeCode);
                p.Add("@CreatedBy", activity.CreatedBy);
                p.Add("@CreatedOn", activity.CreatedOn);
                p.Add("@Origin", activity.Origin);
                p.Add("@Channel", activity.Channel);
                p.Add("@Ip", activity.Ip);
                p.Add("@FingerPrint", activity.FingerPrint);
                p.Add("@Result", activity.Result);
                p.Add("@ChallengeResult", activity.ChallengeResult);
                p.Add("@UpdateBy", activity.UpdateBy);
                p.Add("@UpdateOn", activity.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[Activity] ([Id], [TypeCode], [CreatedBy], [CreatedOn], [Origin], [Channel], [Ip], [FingerPrint], [Result], [ChallengeResult], [UpdateBy], [UpdateOn])  VALUES (@Id, @TypeCode, @CreatedBy, @CreatedOn, @Origin, @Channel, @Ip, @FingerPrint, @Result, @ChallengeResult, @UpdateBy, @UpdateOn)", p, sqlTransaction);

                return true;
            }

        }


        /// <summary>
        /// Update Activity inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(Activity activity, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activity.Id);
                p.Add("@TypeCode", activity.TypeCode);
                p.Add("@CreatedBy", activity.CreatedBy);
                p.Add("@CreatedOn", activity.CreatedOn);
                p.Add("@Origin", activity.Origin);
                p.Add("@Channel", activity.Channel);
                p.Add("@Ip", activity.Ip);
                p.Add("@FingerPrint", activity.FingerPrint);
                p.Add("@Result", activity.Result);
                p.Add("@ChallengeResult", activity.ChallengeResult);
                p.Add("@UpdateBy", activity.UpdateBy);
                p.Add("@UpdateOn", activity.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[Activity]  SET [Id] = @Id, [TypeCode] = @TypeCode, [CreatedBy] = @CreatedBy, [CreatedOn] = @CreatedOn, [Origin] = @Origin, [Channel] = @Channel, [Ip] = @Ip, [FingerPrint] = @FingerPrint, [Result] = @Result, [ChallengeResult] = @ChallengeResult, [UpdateBy] = @UpdateBy, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete Activity
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[Activity] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
