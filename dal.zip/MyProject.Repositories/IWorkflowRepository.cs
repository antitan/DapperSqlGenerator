﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface IWorkflowRepository
    {
        Task<IEnumerable<Workflow>?> GetAllAsync();
        Task<PagedResults<Workflow>> GetPaginatedAsync(Expression<Func<Workflow, bool>>? criteria = null, Expression<Func<Workflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<Workflow?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<Workflow>?> GetByExpressionAsync(Expression<Func<Workflow, bool>> criteria);
        Task<bool> InsertAsync(Workflow workflow);
        Task UpdateAsync(Workflow workflow);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<Workflow, bool>> criteria);
        Task<bool> InsertAsyncTransaction(Workflow workflow, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(Workflow workflow, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction);

    }
}
