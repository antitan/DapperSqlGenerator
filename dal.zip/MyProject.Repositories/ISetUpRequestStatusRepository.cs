﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface ISetUpRequestStatusRepository
    {
        Task<IEnumerable<SetUpRequestStatus>?> GetAllAsync();
        Task<PagedResults<SetUpRequestStatus>> GetPaginatedAsync(Expression<Func<SetUpRequestStatus, bool>>? criteria = null, Expression<Func<SetUpRequestStatus, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<SetUpRequestStatus?> GetByIdAsync(byte id);
        Task<IEnumerable<SetUpRequestStatus>?> GetByExpressionAsync(Expression<Func<SetUpRequestStatus, bool>> criteria);
        Task<byte> InsertAsync(SetUpRequestStatus setUpRequestStatus);
        Task UpdateAsync(SetUpRequestStatus setUpRequestStatus);
        Task DeleteByIdAsync(byte id);
        Task DeleteByExpressionAsync(Expression<Func<SetUpRequestStatus, bool>> criteria);
        Task<byte> InsertAsyncTransaction(SetUpRequestStatus setUpRequestStatus, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(SetUpRequestStatus setUpRequestStatus, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(byte id, SqlTransaction sqlTransaction);

    }
}
