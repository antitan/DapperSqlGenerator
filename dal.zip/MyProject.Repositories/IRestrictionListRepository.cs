﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface IRestrictionListRepository
    {
        Task<IEnumerable<RestrictionList>?> GetAllAsync();
        Task<PagedResults<RestrictionList>> GetPaginatedAsync(Expression<Func<RestrictionList, bool>>? criteria = null, Expression<Func<RestrictionList, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<RestrictionList?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<RestrictionList>?> GetByExpressionAsync(Expression<Func<RestrictionList, bool>> criteria);
        Task<bool> InsertAsync(RestrictionList restrictionList);
        Task UpdateAsync(RestrictionList restrictionList);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<RestrictionList, bool>> criteria);
        Task<bool> InsertAsyncTransaction(RestrictionList restrictionList, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(RestrictionList restrictionList, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction);

    }
}
