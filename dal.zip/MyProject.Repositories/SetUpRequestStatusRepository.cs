﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class SetUpRequestStatusRepository : ISetUpRequestStatusRepository
    {

        private readonly string? connectionString;

        public SetUpRequestStatusRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all SetUpRequestStatus
        /// </summary>
        public async Task<IEnumerable<SetUpRequestStatus>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<SetUpRequestStatus>("SELECT  [Id], [Label]  FROM [dbo].[SetUpRequestStatus] ");
                return entities;
            }
        }

        /// <summary>
        /// Get SetUpRequestStatus by PK
        /// </summary>
        public async Task<SetUpRequestStatus?> GetByIdAsync(byte id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<SetUpRequestStatus>("SELECT  [Id], [Label]  FROM [dbo].[SetUpRequestStatus]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get SetUpRequestStatus by expression 
        /// </summary>
        public async Task<IEnumerable<SetUpRequestStatus>?> GetByExpressionAsync(Expression<Func<SetUpRequestStatus, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [Label] FROM [dbo].[SetUpRequestStatus] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<SetUpRequestStatus>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated SetUpRequestStatus
        /// </summary>
        public async Task<PagedResults<SetUpRequestStatus>> GetPaginatedAsync(Expression<Func<SetUpRequestStatus, bool>>? criteria, Expression<Func<SetUpRequestStatus, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<SetUpRequestStatus>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [Label] FROM [dbo].[SetUpRequestStatus] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[SetUpRequestStatus] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<SetUpRequestStatus>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert SetUpRequestStatus
        /// </summary>
        public async Task<byte> InsertAsync(SetUpRequestStatus setUpRequestStatus)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Label", setUpRequestStatus.Label);

                var result = await connection.QuerySingleAsync<byte>("INSERT INTO [dbo].[SetUpRequestStatus] ([Label])  OUTPUT INSERTED.Id VALUES (@Label)", p);

                return result;
            }

        }


        /// <summary>
        /// Update SetUpRequestStatus
        /// </summary>
        public async Task UpdateAsync(SetUpRequestStatus setUpRequestStatus)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", setUpRequestStatus.Id);
                p.Add("@Label", setUpRequestStatus.Label);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[SetUpRequestStatus]  SET [Label] = @Label WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete SetUpRequestStatus inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(byte id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[SetUpRequestStatus] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete SetUpRequestStatus
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<SetUpRequestStatus, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[SetUpRequestStatus] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert SetUpRequestStatus inside a Transaction
        /// </summary>
        public async Task<byte> InsertAsyncTransaction(SetUpRequestStatus setUpRequestStatus, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Label", setUpRequestStatus.Label);

                var result = await connection.QuerySingleAsync<byte>("INSERT INTO [dbo].[SetUpRequestStatus] ([Label])  OUTPUT INSERTED.Id VALUES (@Label)", p, sqlTransaction);

                return result;
            }

        }


        /// <summary>
        /// Update SetUpRequestStatus inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(SetUpRequestStatus setUpRequestStatus, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", setUpRequestStatus.Id);
                p.Add("@Label", setUpRequestStatus.Label);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[SetUpRequestStatus]  SET [Label] = @Label WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete SetUpRequestStatus
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(byte id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[SetUpRequestStatus] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
