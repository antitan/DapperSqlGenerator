﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class PaymentActivityRepository : IPaymentActivityRepository
    {

        private readonly string? connectionString;

        public PaymentActivityRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all PaymentActivity
        /// </summary>
        public async Task<IEnumerable<PaymentActivity>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<PaymentActivity>("SELECT  [Id], [ActivityId], [AccountNumber], [Bic], [PaymentActivityType], [ExecutionDate], [Amount], [Currency], [CountryDestination], [SourceAccount], [IsNewBeneficiary]  FROM [dbo].[PaymentActivity] ");
                return entities;
            }
        }

        /// <summary>
        /// Get PaymentActivity by PK
        /// </summary>
        public async Task<PaymentActivity?> GetByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<PaymentActivity>("SELECT  [Id], [ActivityId], [AccountNumber], [Bic], [PaymentActivityType], [ExecutionDate], [Amount], [Currency], [CountryDestination], [SourceAccount], [IsNewBeneficiary]  FROM [dbo].[PaymentActivity]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get PaymentActivity by expression 
        /// </summary>
        public async Task<IEnumerable<PaymentActivity>?> GetByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [ActivityId], [AccountNumber], [Bic], [PaymentActivityType], [ExecutionDate], [Amount], [Currency], [CountryDestination], [SourceAccount], [IsNewBeneficiary] FROM [dbo].[PaymentActivity] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<PaymentActivity>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated PaymentActivity
        /// </summary>
        public async Task<PagedResults<PaymentActivity>> GetPaginatedAsync(Expression<Func<PaymentActivity, bool>>? criteria, Expression<Func<PaymentActivity, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<PaymentActivity>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [ActivityId], [AccountNumber], [Bic], [PaymentActivityType], [ExecutionDate], [Amount], [Currency], [CountryDestination], [SourceAccount], [IsNewBeneficiary] FROM [dbo].[PaymentActivity] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[PaymentActivity] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<PaymentActivity>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert PaymentActivity
        /// </summary>
        public async Task<bool> InsertAsync(PaymentActivity paymentActivity)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", paymentActivity.Id);
                p.Add("@ActivityId", paymentActivity.ActivityId);
                p.Add("@AccountNumber", paymentActivity.AccountNumber);
                p.Add("@Bic", paymentActivity.Bic);
                p.Add("@PaymentActivityType", paymentActivity.PaymentActivityType);
                p.Add("@ExecutionDate", paymentActivity.ExecutionDate);
                p.Add("@Amount", paymentActivity.Amount);
                p.Add("@Currency", paymentActivity.Currency);
                p.Add("@CountryDestination", paymentActivity.CountryDestination);
                p.Add("@SourceAccount", paymentActivity.SourceAccount);
                p.Add("@IsNewBeneficiary", paymentActivity.IsNewBeneficiary);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[PaymentActivity] ([Id], [ActivityId], [AccountNumber], [Bic], [PaymentActivityType], [ExecutionDate], [Amount], [Currency], [CountryDestination], [SourceAccount], [IsNewBeneficiary])  VALUES (@Id, @ActivityId, @AccountNumber, @Bic, @PaymentActivityType, @ExecutionDate, @Amount, @Currency, @CountryDestination, @SourceAccount, @IsNewBeneficiary)", p);

                return true;
            }

        }


        /// <summary>
        /// Update PaymentActivity
        /// </summary>
        public async Task UpdateAsync(PaymentActivity paymentActivity)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", paymentActivity.Id);
                p.Add("@ActivityId", paymentActivity.ActivityId);
                p.Add("@AccountNumber", paymentActivity.AccountNumber);
                p.Add("@Bic", paymentActivity.Bic);
                p.Add("@PaymentActivityType", paymentActivity.PaymentActivityType);
                p.Add("@ExecutionDate", paymentActivity.ExecutionDate);
                p.Add("@Amount", paymentActivity.Amount);
                p.Add("@Currency", paymentActivity.Currency);
                p.Add("@CountryDestination", paymentActivity.CountryDestination);
                p.Add("@SourceAccount", paymentActivity.SourceAccount);
                p.Add("@IsNewBeneficiary", paymentActivity.IsNewBeneficiary);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[PaymentActivity]  SET [Id] = @Id, [ActivityId] = @ActivityId, [AccountNumber] = @AccountNumber, [Bic] = @Bic, [PaymentActivityType] = @PaymentActivityType, [ExecutionDate] = @ExecutionDate, [Amount] = @Amount, [Currency] = @Currency, [CountryDestination] = @CountryDestination, [SourceAccount] = @SourceAccount, [IsNewBeneficiary] = @IsNewBeneficiary WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete PaymentActivity inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[PaymentActivity] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete PaymentActivity
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[PaymentActivity] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert PaymentActivity inside a Transaction
        /// </summary>
        public async Task<bool> InsertAsyncTransaction(PaymentActivity paymentActivity, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", paymentActivity.Id);
                p.Add("@ActivityId", paymentActivity.ActivityId);
                p.Add("@AccountNumber", paymentActivity.AccountNumber);
                p.Add("@Bic", paymentActivity.Bic);
                p.Add("@PaymentActivityType", paymentActivity.PaymentActivityType);
                p.Add("@ExecutionDate", paymentActivity.ExecutionDate);
                p.Add("@Amount", paymentActivity.Amount);
                p.Add("@Currency", paymentActivity.Currency);
                p.Add("@CountryDestination", paymentActivity.CountryDestination);
                p.Add("@SourceAccount", paymentActivity.SourceAccount);
                p.Add("@IsNewBeneficiary", paymentActivity.IsNewBeneficiary);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[PaymentActivity] ([Id], [ActivityId], [AccountNumber], [Bic], [PaymentActivityType], [ExecutionDate], [Amount], [Currency], [CountryDestination], [SourceAccount], [IsNewBeneficiary])  VALUES (@Id, @ActivityId, @AccountNumber, @Bic, @PaymentActivityType, @ExecutionDate, @Amount, @Currency, @CountryDestination, @SourceAccount, @IsNewBeneficiary)", p, sqlTransaction);

                return true;
            }

        }


        /// <summary>
        /// Update PaymentActivity inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(PaymentActivity paymentActivity, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", paymentActivity.Id);
                p.Add("@ActivityId", paymentActivity.ActivityId);
                p.Add("@AccountNumber", paymentActivity.AccountNumber);
                p.Add("@Bic", paymentActivity.Bic);
                p.Add("@PaymentActivityType", paymentActivity.PaymentActivityType);
                p.Add("@ExecutionDate", paymentActivity.ExecutionDate);
                p.Add("@Amount", paymentActivity.Amount);
                p.Add("@Currency", paymentActivity.Currency);
                p.Add("@CountryDestination", paymentActivity.CountryDestination);
                p.Add("@SourceAccount", paymentActivity.SourceAccount);
                p.Add("@IsNewBeneficiary", paymentActivity.IsNewBeneficiary);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[PaymentActivity]  SET [Id] = @Id, [ActivityId] = @ActivityId, [AccountNumber] = @AccountNumber, [Bic] = @Bic, [PaymentActivityType] = @PaymentActivityType, [ExecutionDate] = @ExecutionDate, [Amount] = @Amount, [Currency] = @Currency, [CountryDestination] = @CountryDestination, [SourceAccount] = @SourceAccount, [IsNewBeneficiary] = @IsNewBeneficiary WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete PaymentActivity
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[PaymentActivity] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
