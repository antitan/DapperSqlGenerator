﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface IRuleRepository
    {
        Task<IEnumerable<Rule>?> GetAllAsync();
        Task<PagedResults<Rule>> GetPaginatedAsync(Expression<Func<Rule, bool>>? criteria = null, Expression<Func<Rule, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<Rule?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<Rule>?> GetByExpressionAsync(Expression<Func<Rule, bool>> criteria);
        Task<bool> InsertAsync(Rule rule);
        Task UpdateAsync(Rule rule);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<Rule, bool>> criteria);
        Task<bool> InsertAsyncTransaction(Rule rule, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(Rule rule, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction);

    }
}
