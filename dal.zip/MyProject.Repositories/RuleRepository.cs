﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class RuleRepository : IRuleRepository
    {

        private readonly string? connectionString;

        public RuleRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all Rule
        /// </summary>
        public async Task<IEnumerable<Rule>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<Rule>("SELECT  [Id], [WorkFlowId], [ExecutionOrder], [Name], [Description], [Expression], [ErrorMessage], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn]  FROM [dbo].[Rule] ");
                return entities;
            }
        }

        /// <summary>
        /// Get Rule by PK
        /// </summary>
        public async Task<Rule?> GetByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<Rule>("SELECT  [Id], [WorkFlowId], [ExecutionOrder], [Name], [Description], [Expression], [ErrorMessage], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn]  FROM [dbo].[Rule]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get Rule by expression 
        /// </summary>
        public async Task<IEnumerable<Rule>?> GetByExpressionAsync(Expression<Func<Rule, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [WorkFlowId], [ExecutionOrder], [Name], [Description], [Expression], [ErrorMessage], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn] FROM [dbo].[Rule] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<Rule>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated Rule
        /// </summary>
        public async Task<PagedResults<Rule>> GetPaginatedAsync(Expression<Func<Rule, bool>>? criteria, Expression<Func<Rule, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<Rule>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [WorkFlowId], [ExecutionOrder], [Name], [Description], [Expression], [ErrorMessage], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn] FROM [dbo].[Rule] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[Rule] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<Rule>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert Rule
        /// </summary>
        public async Task<bool> InsertAsync(Rule rule)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", rule.Id);
                p.Add("@WorkFlowId", rule.WorkFlowId);
                p.Add("@ExecutionOrder", rule.ExecutionOrder);
                p.Add("@Name", rule.Name);
                p.Add("@Description", rule.Description);
                p.Add("@Expression", rule.Expression);
                p.Add("@ErrorMessage", rule.ErrorMessage);
                p.Add("@CreatedBy", rule.CreatedBy);
                p.Add("@CreatedOn", rule.CreatedOn);
                p.Add("@UpdateBy", rule.UpdateBy);
                p.Add("@UpdateOn", rule.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[Rule] ([Id], [WorkFlowId], [ExecutionOrder], [Name], [Description], [Expression], [ErrorMessage], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn])  VALUES (@Id, @WorkFlowId, @ExecutionOrder, @Name, @Description, @Expression, @ErrorMessage, @CreatedBy, @CreatedOn, @UpdateBy, @UpdateOn)", p);

                return true;
            }

        }


        /// <summary>
        /// Update Rule
        /// </summary>
        public async Task UpdateAsync(Rule rule)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", rule.Id);
                p.Add("@WorkFlowId", rule.WorkFlowId);
                p.Add("@ExecutionOrder", rule.ExecutionOrder);
                p.Add("@Name", rule.Name);
                p.Add("@Description", rule.Description);
                p.Add("@Expression", rule.Expression);
                p.Add("@ErrorMessage", rule.ErrorMessage);
                p.Add("@CreatedBy", rule.CreatedBy);
                p.Add("@CreatedOn", rule.CreatedOn);
                p.Add("@UpdateBy", rule.UpdateBy);
                p.Add("@UpdateOn", rule.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[Rule]  SET [Id] = @Id, [WorkFlowId] = @WorkFlowId, [ExecutionOrder] = @ExecutionOrder, [Name] = @Name, [Description] = @Description, [Expression] = @Expression, [ErrorMessage] = @ErrorMessage, [CreatedBy] = @CreatedBy, [CreatedOn] = @CreatedOn, [UpdateBy] = @UpdateBy, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete Rule inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[Rule] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete Rule
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<Rule, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[Rule] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert Rule inside a Transaction
        /// </summary>
        public async Task<bool> InsertAsyncTransaction(Rule rule, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", rule.Id);
                p.Add("@WorkFlowId", rule.WorkFlowId);
                p.Add("@ExecutionOrder", rule.ExecutionOrder);
                p.Add("@Name", rule.Name);
                p.Add("@Description", rule.Description);
                p.Add("@Expression", rule.Expression);
                p.Add("@ErrorMessage", rule.ErrorMessage);
                p.Add("@CreatedBy", rule.CreatedBy);
                p.Add("@CreatedOn", rule.CreatedOn);
                p.Add("@UpdateBy", rule.UpdateBy);
                p.Add("@UpdateOn", rule.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[Rule] ([Id], [WorkFlowId], [ExecutionOrder], [Name], [Description], [Expression], [ErrorMessage], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn])  VALUES (@Id, @WorkFlowId, @ExecutionOrder, @Name, @Description, @Expression, @ErrorMessage, @CreatedBy, @CreatedOn, @UpdateBy, @UpdateOn)", p, sqlTransaction);

                return true;
            }

        }


        /// <summary>
        /// Update Rule inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(Rule rule, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", rule.Id);
                p.Add("@WorkFlowId", rule.WorkFlowId);
                p.Add("@ExecutionOrder", rule.ExecutionOrder);
                p.Add("@Name", rule.Name);
                p.Add("@Description", rule.Description);
                p.Add("@Expression", rule.Expression);
                p.Add("@ErrorMessage", rule.ErrorMessage);
                p.Add("@CreatedBy", rule.CreatedBy);
                p.Add("@CreatedOn", rule.CreatedOn);
                p.Add("@UpdateBy", rule.UpdateBy);
                p.Add("@UpdateOn", rule.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[Rule]  SET [Id] = @Id, [WorkFlowId] = @WorkFlowId, [ExecutionOrder] = @ExecutionOrder, [Name] = @Name, [Description] = @Description, [Expression] = @Expression, [ErrorMessage] = @ErrorMessage, [CreatedBy] = @CreatedBy, [CreatedOn] = @CreatedOn, [UpdateBy] = @UpdateBy, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete Rule
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[Rule] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
