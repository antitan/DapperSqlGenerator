﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class RestrictionValueRepository : IRestrictionValueRepository
    {

        private readonly string? connectionString;

        public RestrictionValueRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all RestrictionValue
        /// </summary>
        public async Task<IEnumerable<RestrictionValue>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<RestrictionValue>("SELECT  [Id], [RestrictionListId], [Value]  FROM [dbo].[RestrictionValue] ");
                return entities;
            }
        }

        /// <summary>
        /// Get RestrictionValue by PK
        /// </summary>
        public async Task<RestrictionValue?> GetByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<RestrictionValue>("SELECT  [Id], [RestrictionListId], [Value]  FROM [dbo].[RestrictionValue]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get RestrictionValue by expression 
        /// </summary>
        public async Task<IEnumerable<RestrictionValue>?> GetByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [RestrictionListId], [Value] FROM [dbo].[RestrictionValue] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<RestrictionValue>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated RestrictionValue
        /// </summary>
        public async Task<PagedResults<RestrictionValue>> GetPaginatedAsync(Expression<Func<RestrictionValue, bool>>? criteria, Expression<Func<RestrictionValue, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<RestrictionValue>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [RestrictionListId], [Value] FROM [dbo].[RestrictionValue] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[RestrictionValue] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<RestrictionValue>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert RestrictionValue
        /// </summary>
        public async Task<bool> InsertAsync(RestrictionValue restrictionValue)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", restrictionValue.Id);
                p.Add("@RestrictionListId", restrictionValue.RestrictionListId);
                p.Add("@Value", restrictionValue.Value);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[RestrictionValue] ([Id], [RestrictionListId], [Value])  VALUES (@Id, @RestrictionListId, @Value)", p);

                return true;
            }

        }


        /// <summary>
        /// Update RestrictionValue
        /// </summary>
        public async Task UpdateAsync(RestrictionValue restrictionValue)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", restrictionValue.Id);
                p.Add("@RestrictionListId", restrictionValue.RestrictionListId);
                p.Add("@Value", restrictionValue.Value);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[RestrictionValue]  SET [Id] = @Id, [RestrictionListId] = @RestrictionListId, [Value] = @Value WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete RestrictionValue inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[RestrictionValue] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete RestrictionValue
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<RestrictionValue, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[RestrictionValue] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert RestrictionValue inside a Transaction
        /// </summary>
        public async Task<bool> InsertAsyncTransaction(RestrictionValue restrictionValue, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", restrictionValue.Id);
                p.Add("@RestrictionListId", restrictionValue.RestrictionListId);
                p.Add("@Value", restrictionValue.Value);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[RestrictionValue] ([Id], [RestrictionListId], [Value])  VALUES (@Id, @RestrictionListId, @Value)", p, sqlTransaction);

                return true;
            }

        }


        /// <summary>
        /// Update RestrictionValue inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(RestrictionValue restrictionValue, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", restrictionValue.Id);
                p.Add("@RestrictionListId", restrictionValue.RestrictionListId);
                p.Add("@Value", restrictionValue.Value);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[RestrictionValue]  SET [Id] = @Id, [RestrictionListId] = @RestrictionListId, [Value] = @Value WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete RestrictionValue
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[RestrictionValue] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
