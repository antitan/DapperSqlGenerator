﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class WorkflowRepository : IWorkflowRepository
    {

        private readonly string? connectionString;

        public WorkflowRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all Workflow
        /// </summary>
        public async Task<IEnumerable<Workflow>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<Workflow>("SELECT  [Id], [ExecutionOrder], [Name], [ActiveFrom], [ActiveTo], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn]  FROM [dbo].[Workflow] ");
                return entities;
            }
        }

        /// <summary>
        /// Get Workflow by PK
        /// </summary>
        public async Task<Workflow?> GetByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<Workflow>("SELECT  [Id], [ExecutionOrder], [Name], [ActiveFrom], [ActiveTo], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn]  FROM [dbo].[Workflow]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get Workflow by expression 
        /// </summary>
        public async Task<IEnumerable<Workflow>?> GetByExpressionAsync(Expression<Func<Workflow, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [ExecutionOrder], [Name], [ActiveFrom], [ActiveTo], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn] FROM [dbo].[Workflow] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<Workflow>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated Workflow
        /// </summary>
        public async Task<PagedResults<Workflow>> GetPaginatedAsync(Expression<Func<Workflow, bool>>? criteria, Expression<Func<Workflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<Workflow>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [ExecutionOrder], [Name], [ActiveFrom], [ActiveTo], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn] FROM [dbo].[Workflow] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[Workflow] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<Workflow>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert Workflow
        /// </summary>
        public async Task<bool> InsertAsync(Workflow workflow)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", workflow.Id);
                p.Add("@ExecutionOrder", workflow.ExecutionOrder);
                p.Add("@Name", workflow.Name);
                p.Add("@ActiveFrom", workflow.ActiveFrom);
                p.Add("@ActiveTo", workflow.ActiveTo);
                p.Add("@CreatedBy", workflow.CreatedBy);
                p.Add("@CreatedOn", workflow.CreatedOn);
                p.Add("@UpdateBy", workflow.UpdateBy);
                p.Add("@UpdateOn", workflow.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[Workflow] ([Id], [ExecutionOrder], [Name], [ActiveFrom], [ActiveTo], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn])  VALUES (@Id, @ExecutionOrder, @Name, @ActiveFrom, @ActiveTo, @CreatedBy, @CreatedOn, @UpdateBy, @UpdateOn)", p);

                return true;
            }

        }


        /// <summary>
        /// Update Workflow
        /// </summary>
        public async Task UpdateAsync(Workflow workflow)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", workflow.Id);
                p.Add("@ExecutionOrder", workflow.ExecutionOrder);
                p.Add("@Name", workflow.Name);
                p.Add("@ActiveFrom", workflow.ActiveFrom);
                p.Add("@ActiveTo", workflow.ActiveTo);
                p.Add("@CreatedBy", workflow.CreatedBy);
                p.Add("@CreatedOn", workflow.CreatedOn);
                p.Add("@UpdateBy", workflow.UpdateBy);
                p.Add("@UpdateOn", workflow.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[Workflow]  SET [Id] = @Id, [ExecutionOrder] = @ExecutionOrder, [Name] = @Name, [ActiveFrom] = @ActiveFrom, [ActiveTo] = @ActiveTo, [CreatedBy] = @CreatedBy, [CreatedOn] = @CreatedOn, [UpdateBy] = @UpdateBy, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete Workflow inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[Workflow] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete Workflow
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<Workflow, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[Workflow] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert Workflow inside a Transaction
        /// </summary>
        public async Task<bool> InsertAsyncTransaction(Workflow workflow, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", workflow.Id);
                p.Add("@ExecutionOrder", workflow.ExecutionOrder);
                p.Add("@Name", workflow.Name);
                p.Add("@ActiveFrom", workflow.ActiveFrom);
                p.Add("@ActiveTo", workflow.ActiveTo);
                p.Add("@CreatedBy", workflow.CreatedBy);
                p.Add("@CreatedOn", workflow.CreatedOn);
                p.Add("@UpdateBy", workflow.UpdateBy);
                p.Add("@UpdateOn", workflow.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[Workflow] ([Id], [ExecutionOrder], [Name], [ActiveFrom], [ActiveTo], [CreatedBy], [CreatedOn], [UpdateBy], [UpdateOn])  VALUES (@Id, @ExecutionOrder, @Name, @ActiveFrom, @ActiveTo, @CreatedBy, @CreatedOn, @UpdateBy, @UpdateOn)", p, sqlTransaction);

                return true;
            }

        }


        /// <summary>
        /// Update Workflow inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(Workflow workflow, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", workflow.Id);
                p.Add("@ExecutionOrder", workflow.ExecutionOrder);
                p.Add("@Name", workflow.Name);
                p.Add("@ActiveFrom", workflow.ActiveFrom);
                p.Add("@ActiveTo", workflow.ActiveTo);
                p.Add("@CreatedBy", workflow.CreatedBy);
                p.Add("@CreatedOn", workflow.CreatedOn);
                p.Add("@UpdateBy", workflow.UpdateBy);
                p.Add("@UpdateOn", workflow.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[Workflow]  SET [Id] = @Id, [ExecutionOrder] = @ExecutionOrder, [Name] = @Name, [ActiveFrom] = @ActiveFrom, [ActiveTo] = @ActiveTo, [CreatedBy] = @CreatedBy, [CreatedOn] = @CreatedOn, [UpdateBy] = @UpdateBy, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete Workflow
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[Workflow] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
