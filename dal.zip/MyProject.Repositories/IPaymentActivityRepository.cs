﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface IPaymentActivityRepository
    {
        Task<IEnumerable<PaymentActivity>?> GetAllAsync();
        Task<PagedResults<PaymentActivity>> GetPaginatedAsync(Expression<Func<PaymentActivity, bool>>? criteria = null, Expression<Func<PaymentActivity, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<PaymentActivity?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<PaymentActivity>?> GetByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria);
        Task<bool> InsertAsync(PaymentActivity paymentActivity);
        Task UpdateAsync(PaymentActivity paymentActivity);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<PaymentActivity, bool>> criteria);
        Task<bool> InsertAsyncTransaction(PaymentActivity paymentActivity, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(PaymentActivity paymentActivity, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction);

    }
}
