﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class ActivityWorkflowRepository : IActivityWorkflowRepository
    {

        private readonly string? connectionString;

        public ActivityWorkflowRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all ActivityWorkflow
        /// </summary>
        public async Task<IEnumerable<ActivityWorkflow>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<ActivityWorkflow>("SELECT  [Id], [ActivityId], [WorkFlowId], [RuleId], [ExecutionResult]  FROM [dbo].[ActivityWorkflow] ");
                return entities;
            }
        }

        /// <summary>
        /// Get ActivityWorkflow by PK
        /// </summary>
        public async Task<ActivityWorkflow?> GetByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<ActivityWorkflow>("SELECT  [Id], [ActivityId], [WorkFlowId], [RuleId], [ExecutionResult]  FROM [dbo].[ActivityWorkflow]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get ActivityWorkflow by expression 
        /// </summary>
        public async Task<IEnumerable<ActivityWorkflow>?> GetByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [ActivityId], [WorkFlowId], [RuleId], [ExecutionResult] FROM [dbo].[ActivityWorkflow] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<ActivityWorkflow>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated ActivityWorkflow
        /// </summary>
        public async Task<PagedResults<ActivityWorkflow>> GetPaginatedAsync(Expression<Func<ActivityWorkflow, bool>>? criteria, Expression<Func<ActivityWorkflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<ActivityWorkflow>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [ActivityId], [WorkFlowId], [RuleId], [ExecutionResult] FROM [dbo].[ActivityWorkflow] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[ActivityWorkflow] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<ActivityWorkflow>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert ActivityWorkflow
        /// </summary>
        public async Task<bool> InsertAsync(ActivityWorkflow activityWorkflow)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activityWorkflow.Id);
                p.Add("@ActivityId", activityWorkflow.ActivityId);
                p.Add("@WorkFlowId", activityWorkflow.WorkFlowId);
                p.Add("@RuleId", activityWorkflow.RuleId);
                p.Add("@ExecutionResult", activityWorkflow.ExecutionResult);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[ActivityWorkflow] ([Id], [ActivityId], [WorkFlowId], [RuleId], [ExecutionResult])  VALUES (@Id, @ActivityId, @WorkFlowId, @RuleId, @ExecutionResult)", p);

                return true;
            }

        }


        /// <summary>
        /// Update ActivityWorkflow
        /// </summary>
        public async Task UpdateAsync(ActivityWorkflow activityWorkflow)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activityWorkflow.Id);
                p.Add("@ActivityId", activityWorkflow.ActivityId);
                p.Add("@WorkFlowId", activityWorkflow.WorkFlowId);
                p.Add("@RuleId", activityWorkflow.RuleId);
                p.Add("@ExecutionResult", activityWorkflow.ExecutionResult);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[ActivityWorkflow]  SET [Id] = @Id, [ActivityId] = @ActivityId, [WorkFlowId] = @WorkFlowId, [RuleId] = @RuleId, [ExecutionResult] = @ExecutionResult WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete ActivityWorkflow inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[ActivityWorkflow] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete ActivityWorkflow
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[ActivityWorkflow] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert ActivityWorkflow inside a Transaction
        /// </summary>
        public async Task<bool> InsertAsyncTransaction(ActivityWorkflow activityWorkflow, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activityWorkflow.Id);
                p.Add("@ActivityId", activityWorkflow.ActivityId);
                p.Add("@WorkFlowId", activityWorkflow.WorkFlowId);
                p.Add("@RuleId", activityWorkflow.RuleId);
                p.Add("@ExecutionResult", activityWorkflow.ExecutionResult);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[ActivityWorkflow] ([Id], [ActivityId], [WorkFlowId], [RuleId], [ExecutionResult])  VALUES (@Id, @ActivityId, @WorkFlowId, @RuleId, @ExecutionResult)", p, sqlTransaction);

                return true;
            }

        }


        /// <summary>
        /// Update ActivityWorkflow inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(ActivityWorkflow activityWorkflow, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", activityWorkflow.Id);
                p.Add("@ActivityId", activityWorkflow.ActivityId);
                p.Add("@WorkFlowId", activityWorkflow.WorkFlowId);
                p.Add("@RuleId", activityWorkflow.RuleId);
                p.Add("@ExecutionResult", activityWorkflow.ExecutionResult);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[ActivityWorkflow]  SET [Id] = @Id, [ActivityId] = @ActivityId, [WorkFlowId] = @WorkFlowId, [RuleId] = @RuleId, [ExecutionResult] = @ExecutionResult WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete ActivityWorkflow
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[ActivityWorkflow] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
