﻿using Dapper;
using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;
using MyProject.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace MyProject.Repositories
{

    public class SetUpRequestRepository : ISetUpRequestRepository
    {

        private readonly string? connectionString;

        public SetUpRequestRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        #region Generated

        /// <summary>
        /// Get all SetUpRequest
        /// </summary>
        public async Task<IEnumerable<SetUpRequest>?> GetAllAsync()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var entities = await connection.QueryAsync<SetUpRequest>("SELECT  [Id], [ActivityId], [SetUpRequestStatusId], [UpdateOn]  FROM [dbo].[SetUpRequest] ");
                return entities;
            }
        }

        /// <summary>
        /// Get SetUpRequest by PK
        /// </summary>
        public async Task<SetUpRequest?> GetByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                var entity = await connection.QuerySingleOrDefaultAsync<SetUpRequest>("SELECT  [Id], [ActivityId], [SetUpRequestStatusId], [UpdateOn]  FROM [dbo].[SetUpRequest]  WHERE [Id] = @Id ", p);
                return entity;

            }
        }


        /// <summary>
        /// Get SetUpRequest by expression 
        /// </summary>
        public async Task<IEnumerable<SetUpRequest>?> GetByExpressionAsync(Expression<Func<SetUpRequest, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var querySelect = $"SELECT [Id], [ActivityId], [SetUpRequestStatusId], [UpdateOn] FROM [dbo].[SetUpRequest] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var entities = await connection.QueryAsync<SetUpRequest>(querySelect);
                return entities;
            }
        }

        /// <summary>
        /// Get paginated SetUpRequest
        /// </summary>
        public async Task<PagedResults<SetUpRequest>> GetPaginatedAsync(Expression<Func<SetUpRequest, bool>>? criteria, Expression<Func<SetUpRequest, object>>? orderByExpression = null, int page = 1, int pageSize = 10)
        {
            var results = new PagedResults<SetUpRequest>();

            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var querySelect = $"SELECT [Id], [ActivityId], [SetUpRequestStatusId], [UpdateOn] FROM [dbo].[SetUpRequest] ";
                if (criteria != null)
                {
                    querySelect += $" WHERE {criteria.ToMSSqlString()} ";
                }
                var orderComputedExpression = (orderByExpression == null) ? "1" : orderByExpression.ToMSSqlString();
                querySelect += $" ORDER BY {orderComputedExpression}  ";
                querySelect += $" OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var queryCount = $"SELECT  count(*)  FROM [dbo].[SetUpRequest] ";
                if (criteria != null)
                {
                    queryCount += $" WHERE {criteria.ToMSSqlString()} ";
                }

                var query = $"{querySelect} {queryCount} ";
                using (var multi = await connection.QueryMultipleAsync(query,
                    new
                    {
                        Offset = (page - 1) * pageSize,
                        PageSize = pageSize
                    }))
                {
                    results.Items = multi.Read<SetUpRequest>();
                    results.TotalCount = multi.ReadFirst<int>();
                    results.PageIndex = page;
                    results.PageSize = pageSize;
                }
            }
            return results;
        }

        /// <summary>
        /// Insert SetUpRequest
        /// </summary>
        public async Task<bool> InsertAsync(SetUpRequest setUpRequest)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", setUpRequest.Id);
                p.Add("@ActivityId", setUpRequest.ActivityId);
                p.Add("@SetUpRequestStatusId", setUpRequest.SetUpRequestStatusId);
                p.Add("@UpdateOn", setUpRequest.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[SetUpRequest] ([Id], [ActivityId], [SetUpRequestStatusId], [UpdateOn])  VALUES (@Id, @ActivityId, @SetUpRequestStatusId, @UpdateOn)", p);

                return true;
            }

        }


        /// <summary>
        /// Update SetUpRequest
        /// </summary>
        public async Task UpdateAsync(SetUpRequest setUpRequest)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", setUpRequest.Id);
                p.Add("@ActivityId", setUpRequest.ActivityId);
                p.Add("@SetUpRequestStatusId", setUpRequest.SetUpRequestStatusId);
                p.Add("@UpdateOn", setUpRequest.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[SetUpRequest]  SET [Id] = @Id, [ActivityId] = @ActivityId, [SetUpRequestStatusId] = @SetUpRequestStatusId, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete SetUpRequest inside a Transaction
        /// </summary>
        public async Task DeleteByIdAsync(System.Guid id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[SetUpRequest] WHERE [Id] = @Id", p);
            }

        }


        /// <summary>
        /// Delete SetUpRequest
        /// </summary>
        public async Task DeleteByExpressionAsync(Expression<Func<SetUpRequest, bool>> criteria)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.ExecuteAsync($"DELETE FROM [dbo].[SetUpRequest] WHERE  {criteria.ToMSSqlString()} ");
            }
        }


        /// <summary>
        /// Insert SetUpRequest inside a Transaction
        /// </summary>
        public async Task<bool> InsertAsyncTransaction(SetUpRequest setUpRequest, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", setUpRequest.Id);
                p.Add("@ActivityId", setUpRequest.ActivityId);
                p.Add("@SetUpRequestStatusId", setUpRequest.SetUpRequestStatusId);
                p.Add("@UpdateOn", setUpRequest.UpdateOn);

                var result = await connection.ExecuteAsync("INSERT INTO [dbo].[SetUpRequest] ([Id], [ActivityId], [SetUpRequestStatusId], [UpdateOn])  VALUES (@Id, @ActivityId, @SetUpRequestStatusId, @UpdateOn)", p, sqlTransaction);

                return true;
            }

        }


        /// <summary>
        /// Update SetUpRequest inside a Transaction
        /// </summary>
        public async Task UpdateAsyncTransaction(SetUpRequest setUpRequest, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", setUpRequest.Id);
                p.Add("@ActivityId", setUpRequest.ActivityId);
                p.Add("@SetUpRequestStatusId", setUpRequest.SetUpRequestStatusId);
                p.Add("@UpdateOn", setUpRequest.UpdateOn);

                await connection.ExecuteScalarAsync<int>("UPDATE [dbo].[SetUpRequest]  SET [Id] = @Id, [ActivityId] = @ActivityId, [SetUpRequestStatusId] = @SetUpRequestStatusId, [UpdateOn] = @UpdateOn WHERE [Id] = @Id", p, sqlTransaction);
            }

        }


        /// <summary>
        /// Delete SetUpRequest
        /// </summary>
        public async Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var p = new DynamicParameters();
                p.Add("@Id", id);

                await connection.ExecuteScalarAsync<int>("DELETE FROM [dbo].[SetUpRequest] WHERE [Id] = @Id", p, sqlTransaction);
            }

        }

        #endregion Generated


    }

}
