﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface IActivityWorkflowRepository
    {
        Task<IEnumerable<ActivityWorkflow>?> GetAllAsync();
        Task<PagedResults<ActivityWorkflow>> GetPaginatedAsync(Expression<Func<ActivityWorkflow, bool>>? criteria = null, Expression<Func<ActivityWorkflow, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<ActivityWorkflow?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<ActivityWorkflow>?> GetByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria);
        Task<bool> InsertAsync(ActivityWorkflow activityWorkflow);
        Task UpdateAsync(ActivityWorkflow activityWorkflow);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<ActivityWorkflow, bool>> criteria);
        Task<bool> InsertAsyncTransaction(ActivityWorkflow activityWorkflow, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(ActivityWorkflow activityWorkflow, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction);

    }
}
