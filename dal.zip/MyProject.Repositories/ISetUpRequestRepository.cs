﻿using System.Linq.Expressions;
using MyProject.Business.DataModel;
using MyProject.Common.Pagination;

namespace MyProject.Repositories
{
    public partial interface ISetUpRequestRepository
    {
        Task<IEnumerable<SetUpRequest>?> GetAllAsync();
        Task<PagedResults<SetUpRequest>> GetPaginatedAsync(Expression<Func<SetUpRequest, bool>>? criteria = null, Expression<Func<SetUpRequest, object>>? orderByExpression = null, int page = 1, int pageSize = 10);
        Task<SetUpRequest?> GetByIdAsync(System.Guid id);
        Task<IEnumerable<SetUpRequest>?> GetByExpressionAsync(Expression<Func<SetUpRequest, bool>> criteria);
        Task<bool> InsertAsync(SetUpRequest setUpRequest);
        Task UpdateAsync(SetUpRequest setUpRequest);
        Task DeleteByIdAsync(System.Guid id);
        Task DeleteByExpressionAsync(Expression<Func<SetUpRequest, bool>> criteria);
        Task<bool> InsertAsyncTransaction(SetUpRequest setUpRequest, SqlTransaction sqlTransaction);
        Task UpdateAsyncTransaction(SetUpRequest setUpRequest, SqlTransaction sqlTransaction);
        Task DeleteByIdAsyncTransaction(System.Guid id, SqlTransaction sqlTransaction);

    }
}
