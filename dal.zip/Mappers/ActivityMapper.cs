﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class ActivityMapper
    {
        public static Activity ToEntity(this ActivityRequestAddDto dto)
        {
            return new Activity
            {

                TypeCode = dto.TypeCode,
                CreatedBy = dto.CreatedBy,
                CreatedOn = dto.CreatedOn,
                Origin = dto.Origin,
                Channel = dto.Channel,
                Ip = dto.Ip,
                FingerPrint = dto.FingerPrint,
                Result = dto.Result,
                ChallengeResult = dto.ChallengeResult,
                UpdateBy = dto.UpdateBy,
                UpdateOn = dto.UpdateOn,
            };
        }

        public static ActivityResponseGetByIdDto ToGetByIdDto(this Activity entity)
        {
            return new ActivityResponseGetByIdDto
            {

            };
        }

    }

}
