﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class SetUpRequestStatusMapper
    {
        public static SetUpRequestStatus ToEntity(this SetUpRequestStatusRequestAddDto dto)
        {
            return new SetUpRequestStatus
            {

                Label = dto.Label,
            };
        }

        public static SetUpRequestStatusResponseGetByIdDto ToGetByIdDto(this SetUpRequestStatus entity)
        {
            return new SetUpRequestStatusResponseGetByIdDto
            {

            };
        }

    }

}
