﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class SetUpRequestMapper
    {
        public static SetUpRequest ToEntity(this SetUpRequestRequestAddDto dto)
        {
            return new SetUpRequest
            {

                ActivityId = dto.ActivityId,
                SetUpRequestStatusId = dto.SetUpRequestStatusId,
                UpdateOn = dto.UpdateOn,
            };
        }

        public static SetUpRequestResponseGetByIdDto ToGetByIdDto(this SetUpRequest entity)
        {
            return new SetUpRequestResponseGetByIdDto
            {

            };
        }

    }

}
