﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class WorkflowMapper
    {
        public static Workflow ToEntity(this WorkflowRequestAddDto dto)
        {
            return new Workflow
            {

                ExecutionOrder = dto.ExecutionOrder,
                Name = dto.Name,
                ActiveFrom = dto.ActiveFrom,
                ActiveTo = dto.ActiveTo,
                CreatedBy = dto.CreatedBy,
                CreatedOn = dto.CreatedOn,
                UpdateBy = dto.UpdateBy,
                UpdateOn = dto.UpdateOn,
            };
        }

        public static WorkflowResponseGetByIdDto ToGetByIdDto(this Workflow entity)
        {
            return new WorkflowResponseGetByIdDto
            {

            };
        }

    }

}
