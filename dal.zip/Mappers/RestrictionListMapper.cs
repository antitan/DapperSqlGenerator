﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class RestrictionListMapper
    {
        public static RestrictionList ToEntity(this RestrictionListRequestAddDto dto)
        {
            return new RestrictionList
            {

                Name = dto.Name,
            };
        }

        public static RestrictionListResponseGetByIdDto ToGetByIdDto(this RestrictionList entity)
        {
            return new RestrictionListResponseGetByIdDto
            {

            };
        }

    }

}
