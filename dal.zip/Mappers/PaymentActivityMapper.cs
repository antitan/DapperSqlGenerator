﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class PaymentActivityMapper
    {
        public static PaymentActivity ToEntity(this PaymentActivityRequestAddDto dto)
        {
            return new PaymentActivity
            {

                ActivityId = dto.ActivityId,
                AccountNumber = dto.AccountNumber,
                Bic = dto.Bic,
                PaymentActivityType = dto.PaymentActivityType,
                ExecutionDate = dto.ExecutionDate,
                Amount = dto.Amount,
                Currency = dto.Currency,
                CountryDestination = dto.CountryDestination,
                SourceAccount = dto.SourceAccount,
                IsNewBeneficiary = dto.IsNewBeneficiary,
            };
        }

        public static PaymentActivityResponseGetByIdDto ToGetByIdDto(this PaymentActivity entity)
        {
            return new PaymentActivityResponseGetByIdDto
            {

            };
        }

    }

}
