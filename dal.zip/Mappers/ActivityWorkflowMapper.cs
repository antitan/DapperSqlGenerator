﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class ActivityWorkflowMapper
    {
        public static ActivityWorkflow ToEntity(this ActivityWorkflowRequestAddDto dto)
        {
            return new ActivityWorkflow
            {

                ActivityId = dto.ActivityId,
                WorkFlowId = dto.WorkFlowId,
                RuleId = dto.RuleId,
                ExecutionResult = dto.ExecutionResult,
            };
        }

        public static ActivityWorkflowResponseGetByIdDto ToGetByIdDto(this ActivityWorkflow entity)
        {
            return new ActivityWorkflowResponseGetByIdDto
            {

            };
        }

    }

}
