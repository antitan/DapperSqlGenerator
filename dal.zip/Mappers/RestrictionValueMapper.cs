﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class RestrictionValueMapper
    {
        public static RestrictionValue ToEntity(this RestrictionValueRequestAddDto dto)
        {
            return new RestrictionValue
            {

                RestrictionListId = dto.RestrictionListId,
                Value = dto.Value,
            };
        }

        public static RestrictionValueResponseGetByIdDto ToGetByIdDto(this RestrictionValue entity)
        {
            return new RestrictionValueResponseGetByIdDto
            {

            };
        }

    }

}
