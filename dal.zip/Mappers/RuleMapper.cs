﻿using Dakota.Contacts.WebApi.Requests;
using Dakota.Contacts.Models;
using Dakota.Contacts.WebApi.Response;

namespace Dakota.Contacts.WebApi.Mappers
{

    public static class RuleMapper
    {
        public static Rule ToEntity(this RuleRequestAddDto dto)
        {
            return new Rule
            {

                WorkFlowId = dto.WorkFlowId,
                ExecutionOrder = dto.ExecutionOrder,
                Name = dto.Name,
                Description = dto.Description,
                Expression = dto.Expression,
                ErrorMessage = dto.ErrorMessage,
                CreatedBy = dto.CreatedBy,
                CreatedOn = dto.CreatedOn,
                UpdateBy = dto.UpdateBy,
                UpdateOn = dto.UpdateOn,
            };
        }

        public static RuleResponseGetByIdDto ToGetByIdDto(this Rule entity)
        {
            return new RuleResponseGetByIdDto
            {

            };
        }

    }

}
