namespace MyProject.Common.Constants
{
    public static class CacheDataConstants
    {
       public static string SetUpRequestStatusAllCacheKey = "SetUpRequestStatus.all";
    }
}
