﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class ActivityRequestAddDto
    {

        public char TypeCode { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string Origin { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string Channel { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(39)]
        public string Ip { get; set; }
        public string FingerPrint { get; set; }
        public bool Result { get; set; }
        public bool? ChallengeResult { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string UpdateBy { get; set; }
        public System.DateTime? UpdateOn { get; set; }
    }
    public class ActivityRequestUpdateDto : ActivityRequestAddDto
    {
        public System.Guid Id { get; set; }












    }

}
