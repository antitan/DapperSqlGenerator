﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class SetUpRequestRequestAddDto
    {

        public System.Guid ActivityId { get; set; }
        public byte SetUpRequestStatusId { get; set; }
        public System.DateTime UpdateOn { get; set; }
    }
    public class SetUpRequestRequestUpdateDto : SetUpRequestRequestAddDto
    {
        public System.Guid Id { get; set; }




    }

}
