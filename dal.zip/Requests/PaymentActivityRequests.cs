﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class PaymentActivityRequestAddDto
    {

        public System.Guid ActivityId { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(500)]
        public string AccountNumber { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(200)]
        public string Bic { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string PaymentActivityType { get; set; }
        public System.DateTime ExecutionDate { get; set; }
        public decimal Amount { get; set; }
        public char Currency { get; set; }
        public char CountryDestination { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(500)]
        public string SourceAccount { get; set; }
        public bool IsNewBeneficiary { get; set; }
    }
    public class PaymentActivityRequestUpdateDto : PaymentActivityRequestAddDto
    {
        public System.Guid Id { get; set; }











    }

}
