﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class ActivityWorkflowRequestAddDto
    {

        public System.Guid ActivityId { get; set; }
        public System.Guid WorkFlowId { get; set; }
        public System.Guid RuleId { get; set; }
        public bool ExecutionResult { get; set; }
    }
    public class ActivityWorkflowRequestUpdateDto : ActivityWorkflowRequestAddDto
    {
        public System.Guid Id { get; set; }





    }

}
