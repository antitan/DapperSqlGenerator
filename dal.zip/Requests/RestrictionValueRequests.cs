﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class RestrictionValueRequestAddDto
    {

        public System.Guid RestrictionListId { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(500)]
        public string Value { get; set; }
    }
    public class RestrictionValueRequestUpdateDto : RestrictionValueRequestAddDto
    {
        public System.Guid Id { get; set; }



    }

}
