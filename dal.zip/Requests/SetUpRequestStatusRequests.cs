﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class SetUpRequestStatusRequestAddDto
    {

        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string Label { get; set; }
    }
    public class SetUpRequestStatusRequestUpdateDto : SetUpRequestStatusRequestAddDto
    {
        public byte Id { get; set; }


    }

}
