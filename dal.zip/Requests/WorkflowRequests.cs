﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class WorkflowRequestAddDto
    {

        public short ExecutionOrder { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(100)]
        public string Name { get; set; }
        public System.DateTime ActiveFrom { get; set; }
        public System.DateTime? ActiveTo { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string UpdateBy { get; set; }
        public System.DateTime? UpdateOn { get; set; }
    }
    public class WorkflowRequestUpdateDto : WorkflowRequestAddDto
    {
        public System.Guid Id { get; set; }









    }

}
