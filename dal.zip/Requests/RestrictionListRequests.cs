﻿using Dakota.Contacts.Models;

namespace Dakota.Contacts.WebApi.Requests
{

    public class RestrictionListRequestAddDto
    {

        [System.ComponentModel.DataAnnotations.StringLength(100)]
        public string Name { get; set; }
    }
    public class RestrictionListRequestUpdateDto : RestrictionListRequestAddDto
    {
        public System.Guid Id { get; set; }


    }

}
