﻿namespace Dakota.Contacts.WebApi.Response
{

    public class SetUpRequestStatusResponseGetByIdDto
    {

    }

}
