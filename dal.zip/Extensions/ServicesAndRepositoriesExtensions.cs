using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MyProject.Repositories;
using MyProject.Services;

namespace MyProject.WebApi.Extensions
{

    public static class ServicesAndRepositoriesExtensions
    {
        public static IServiceCollection AddRegisterServicesAndRepositories(this IServiceCollection services,
          IConfiguration config)
        {
            services.AddScoped<IRuleRepository,RuleRepository>();
services.AddScoped<ISetUpRequestStatusRepository,SetUpRequestStatusRepository>();
services.AddScoped<IPaymentActivityRepository,PaymentActivityRepository>();
services.AddScoped<IRestrictionValueRepository,RestrictionValueRepository>();
services.AddScoped<IActivityRepository,ActivityRepository>();
services.AddScoped<ISetUpRequestRepository,SetUpRequestRepository>();
services.AddScoped<IWorkflowRepository,WorkflowRepository>();
services.AddScoped<IRestrictionListRepository,RestrictionListRepository>();
services.AddScoped<IActivityWorkflowRepository,ActivityWorkflowRepository>();
            services.AddScoped<IRuleService,RuleService>();
services.AddScoped<ISetUpRequestStatusService,SetUpRequestStatusService>();
services.AddScoped<IPaymentActivityService,PaymentActivityService>();
services.AddScoped<IRestrictionValueService,RestrictionValueService>();
services.AddScoped<IActivityService,ActivityService>();
services.AddScoped<ISetUpRequestService,SetUpRequestService>();
services.AddScoped<IWorkflowService,WorkflowService>();
services.AddScoped<IRestrictionListService,RestrictionListService>();
services.AddScoped<IActivityWorkflowService,ActivityWorkflowService>();

            return services;
        }
    }
}
