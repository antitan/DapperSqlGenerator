﻿using System;
namespace MyProject.Business.DataModel
{
    public class Rule
    {
        public System.Guid Id { get; set; }

        public System.Guid WorkFlowId { get; set; }

        public short ExecutionOrder { get; set; }

        [System.ComponentModel.DataAnnotations.StringLength(100)]
        public string Name { get; set; }

        [System.ComponentModel.DataAnnotations.StringLength(500)]
        public string Description { get; set; }

        public string Expression { get; set; }

        public string ErrorMessage { get; set; }

        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string CreatedBy { get; set; }

        public System.DateTime CreatedOn { get; set; }

        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string UpdateBy { get; set; }

        public System.DateTime? UpdateOn { get; set; }

    }
}

