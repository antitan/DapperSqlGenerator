﻿using System;
namespace MyProject.Business.DataModel
{
    public class RestrictionValue
    {
        public System.Guid Id { get; set; }

        public System.Guid RestrictionListId { get; set; }

        [System.ComponentModel.DataAnnotations.StringLength(500)]
        public string Value { get; set; }

    }
}

