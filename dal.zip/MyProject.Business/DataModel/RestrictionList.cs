﻿using System;
namespace MyProject.Business.DataModel
{
    public class RestrictionList
    {
        public System.Guid Id { get; set; }

        [System.ComponentModel.DataAnnotations.StringLength(100)]
        public string Name { get; set; }

    }
}

