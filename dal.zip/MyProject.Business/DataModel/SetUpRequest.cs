﻿using System;
namespace MyProject.Business.DataModel
{
    public class SetUpRequest
    {
        public System.Guid Id { get; set; }

        public System.Guid ActivityId { get; set; }

        public byte SetUpRequestStatusId { get; set; }

        public System.DateTime UpdateOn { get; set; }

    }
}

