﻿using System;
namespace MyProject.Business.DataModel
{
    public class SetUpRequestStatus
    {
        public byte Id { get; set; }

        [System.ComponentModel.DataAnnotations.StringLength(50)]
        public string Label { get; set; }

    }
}

