﻿using System;
namespace MyProject.Business.DataModel
{
    public class ActivityWorkflow
    {
        public System.Guid Id { get; set; }

        public System.Guid ActivityId { get; set; }

        public System.Guid WorkFlowId { get; set; }

        public System.Guid RuleId { get; set; }

        public bool ExecutionResult { get; set; }

    }
}

